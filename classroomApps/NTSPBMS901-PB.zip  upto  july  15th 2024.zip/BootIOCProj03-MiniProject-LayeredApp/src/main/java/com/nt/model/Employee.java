package com.nt.model;

import lombok.Data;

@Data
public class Employee {
	private  Integer empno;
	private  String  ename;
	private  String  job;
	private  Float sal;
	private  Integer deptno;
	private  Float    grossSalary;
	private   Float  netSalary;

}
