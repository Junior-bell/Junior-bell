package com.nt.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.Data;

@Entity
@Table(name="JPA_BANKAccount")
@Data
public class BankAccount {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long  accno;
	@Column(length=25)
	private  String holderName;
	private   Double balance;
	
	@Version
	private  Integer version;
	
    @CreationTimestamp
	private  LocalDateTime createdOn;
	@UpdateTimestamp
	private   LocalDateTime  updatedOn;
	
	

}
