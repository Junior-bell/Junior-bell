package com.nt.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.BankAccount;
import com.nt.service.IBankMgmtService;

@Component
public class VersioningAndTimestampRunner implements CommandLineRunner {
	@Autowired
	private  IBankMgmtService  bankService;

	@Override
	public void run(String... args) throws Exception {
		/* BankAccount account=new BankAccount();
		 account.setHolderName("raja"); account.setBalance(90000.0);
		String msg=bankService.registerAccount(account);
		System.out.println(msg);*/

		
	 String msg1=bankService.withdraw(1, 3000.0);
			 System.out.println(msg1);
		
	}

}
