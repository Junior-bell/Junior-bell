package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj06VersioningAndTimeStampingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj06VersioningAndTimeStampingApplication.class, args);
	}

}
