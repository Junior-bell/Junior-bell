package com.nt.service;

import com.nt.entity.BankAccount;

public interface IBankMgmtService {
	public   String  registerAccount(BankAccount account);
	public   String   withdraw(long accno, double amount);
	public   String   deposite(long accno, double amount);
	
}
