package com.nt.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.BankAccount;
import com.nt.repository.IBankAccountRepository;

@Service
public class BankMgmtServiceImpl implements IBankMgmtService {
	@Autowired
	private  IBankAccountRepository   bankRepo;

	@Override
	public String registerAccount(BankAccount account) {
		long idVal=bankRepo.save(account).getAccno();
		return "Bank account is created with the  account number::"+idVal;
	}

	@Override
	public String withdraw(long accno, double amount) {
		//Load ohject
		Optional<BankAccount> opt=bankRepo.findById(accno);
		if(opt.isPresent()) {
			BankAccount  acc=opt.get();
			acc.setBalance(acc.getBalance()-amount);
			 bankRepo.save(acc);
			return "Bank account updated with balanace:"+accno;
		}
		else{
			return "bank account is not found";
		}
	}
	
		@Override
		public String deposite(long accno, double amount) {
			//Load ohject
			Optional<BankAccount> opt=bankRepo.findById(accno);
			if(opt.isPresent()) {
				BankAccount  acc=opt.get();
				acc.setBalance(acc.getBalance()+amount);
				 bankRepo.save(acc);
				return "Bank account is deposited with money:"+accno;
			}
			else {
		            return "Bank account is not found";
			}
	}

	
	
	
	

}
