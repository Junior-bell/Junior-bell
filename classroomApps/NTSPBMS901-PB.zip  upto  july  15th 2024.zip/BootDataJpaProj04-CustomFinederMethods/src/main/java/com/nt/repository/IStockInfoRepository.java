package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nt.entity.StockInfo;

public interface IStockInfoRepository extends  JpaRepository<StockInfo, Integer>                                                                                     {
         public List<StockInfo>  findByExchangeName(String  exchange);
         public List<StockInfo>  findByExchangeNameIs(String  exchange);
         
         public  List<StockInfo>  readByCompanyStartingWith(String initialChars);
         public  List<StockInfo>  findByCompanyEndingWith(String lastChars);
         public   List<StockInfo>   getByCompanyContainingIgnoreCase(String  chars);
         
         public  List<StockInfo>    findByExchangeNameIn(List<String>  exchangeNamesList);
         
         public  List<StockInfo>   findByPriceGreaterThanEqualAndPriceLessThanEqual(float startPrice, float endPrice);
         

		
}
