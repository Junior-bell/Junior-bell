package com.nt.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.repository.IStockInfoRepository;

@Component
public class JpaRepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private  IStockInfoRepository  stockRepo;
	
	@Override
	public void run(String... args) throws Exception {
 
		  //stockRepo.findByExchangeName("NSE").forEach(System.out::println);
		  
		   //stockRepo.readByCompanyStartingWith("ad").forEach(System.out::println);
		//stockRepo.findByCompanyEndingWith("p").forEach(System.out::println);
	      stockRepo.getByCompanyContainingIgnoreCase("group").forEach(System.out::println);
		//  stockRepo.findByExchangeNameIn(List.of("BSE","NSE")).forEach(System.out::println);
		  //stockRepo.findByPriceGreaterThanEqualAndPriceLessThanEqual(300.0f, 4000.0f).forEach(System.out::println);
		  
	}// main

}// class
