package com.nt.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Person;
import com.nt.entity.PhoneNumber;
import com.nt.repository.IPersonRepository;
import com.nt.repository.IPhoneNumberRepository;

@Service
public class PersonMgmtServiceImpl implements IPersonMgmtService {
	@Autowired
	private IPersonRepository personRepo;
	@Autowired
	private  IPhoneNumberRepository  phoneRepo;

	@Override
	public List<Object[]> fetchParentToChildJoinsData() {
		//use  repo
		return personRepo.showJoinsDataParentToChild();
	}
	
	@Override
	public List<Object[]> fetchChildToParentJoinsData() {
		
		return phoneRepo.showJoinsDataChildToParent();
	}
}
