package com.nt.runners;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.service.IPersonMgmtService;

@Component
public class OTMAssociationMappingTestingRunner implements CommandLineRunner {
	@Autowired
	 private IPersonMgmtService  personService;
	@Override
	public void run(String... args) throws Exception {
		/*personService.saveDataUsingParent();
		 personService.saveDataUsingChild();*/
		
		  //personService.loadDataUsingParent();
		   //personService.loadDataUsingChild();
		
		   // System.out.println(personService.deleteByParent(1));
		//System.out.println(personService.deleteAllChildsOfAParent(2));
		
			/*   personService.fetchParentToChildJoinsData().forEach(row->{
				   System.out.println(Arrays.toString(row));
			   });*/
		  personService.fetchChildToParentJoinsData().forEach(row->{
			  System.out.println(Arrays.toString(row));
		  });
		
	}

}
