package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.PhoneNumber;

public interface IPhoneNumberRepository extends JpaRepository<PhoneNumber, Integer> {
	//@Query("select ph.regId,ph.type,ph.provider,ph.phone,p.pid,p.pname,p.paddrs  from PhoneNumber  ph  inner join ph.person p")
	@Query("select ph.regId,ph.type,ph.provider,ph.phone,p.pid,p.pname,p.paddrs  from PhoneNumber  ph  full join ph.person p")
	
	public    List<Object[]>  showJoinsDataChildToParent();
}
