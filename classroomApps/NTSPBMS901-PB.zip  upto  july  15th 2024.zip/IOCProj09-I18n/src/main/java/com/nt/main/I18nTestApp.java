package com.nt.main;

import java.util.Locale;
import java.util.Scanner;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nt.config.AppConfig;

public class I18nTestApp {

	public static void main(String[] args) {
		//read  Language code and  conuntry code
		Scanner sc=new Scanner(System.in);
		System.out.println("enter  language Code::");
		String lang=sc.next();
		System.out.println("enter  country Code::");
		String country=sc.next();
		//parepare  Locale object having language and  country code
		Locale locale=new Locale(lang,country);
		
		
		//create the IOC container
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(AppConfig.class);
		
		//get Messages  from the specific properties file by passing the Locale and key
		String msg1=ctx.getMessage("welcome.msg", new Object[] {"raja" },locale);
		String msg2=ctx.getMessage("goodbye.message", new Object[] { },locale);
		String msg3=ctx.getMessage("warm.message", new Object[] { },locale);
		System.out.println(msg1+" ......"+msg2+"....."+msg3);
		
		//the close the container
		 ctx.close();

	}

}
