package com.nt.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.controller.EmployeeOperationsController;
import com.nt.model.Employee;

@Component
public class MiniProjectTestRunner implements CommandLineRunner {
	@Autowired
	private   EmployeeOperationsController  controller;

	@Override
	public void run(String... args) throws Exception {
		System.out.println("MiniProjectTestRunner.run()");
		
		List<Employee> list=controller.getEmployeesByDesgs("CLERK", "MANAGER", "SALESMAN");
		list.forEach(System.out::println);

	}

}
