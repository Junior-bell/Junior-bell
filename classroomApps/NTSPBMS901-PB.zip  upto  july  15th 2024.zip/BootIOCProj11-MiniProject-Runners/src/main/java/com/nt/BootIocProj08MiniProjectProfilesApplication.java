package com.nt;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.nt.controller.EmployeeOperationsController;
import com.nt.model.Employee;

@SpringBootApplication
public  class BootIocProj08MiniProjectProfilesApplication {

	public static void main(String[] args) {
		//get  Access to IOC container
		SpringApplication.run(BootIocProj08MiniProjectProfilesApplication.class, args);
	
	}

}
