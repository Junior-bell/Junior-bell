package com.nt.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.service.IStockMgmtService;

@Component
public class PL_SQLProcedureCallTestRunner implements CommandLineRunner {
	@Autowired
	private IStockMgmtService  stockService;

	@Override
	public void run(String... args) throws Exception {
		stockService.showStocksByPriceRange(400.0, 20000.0).forEach(System.out::println);
	}

}
