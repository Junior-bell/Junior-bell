package com.nt.service;

import java.util.List;

import com.nt.entity.StockInfo;

public interface IStockMgmtService {
   public  List<StockInfo>  showStocksByPriceRange(double start,double end);
}
