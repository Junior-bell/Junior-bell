package com.nt;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import com.nt.controller.EmployeeOperationsController;
import com.nt.model.Employee;

@SpringBootApplication
public  class BootIocProj13MiniProjectProfilesApplication {

	public static void main(String[] args) {
		//get  Access to IOC container
		SpringApplication  application=new SpringApplication(BootIocProj13MiniProjectProfilesApplication.class);
		  application.setAdditionalProfiles("dev");  //active profile
		 ApplicationContext ctx=application.run(args);
		
		
		// get  Controller class obj
		EmployeeOperationsController  controller=ctx.getBean("empController",EmployeeOperationsController.class);
	    //invoke the b.method
		try {
			List<Employee> list=controller.getEmployeesByDesgs("CLERK", "MANAGER", "SALESMAN");
			list.forEach(emp->{
				System.out.println(emp);
			});
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("=============================");
		Environment env=ctx.getEnvironment();
		System.out.println("current active profile ::"+Arrays.toString(env.getActiveProfiles()));
		
		//close the container
		  ((ConfigurableApplicationContext) ctx).close();
	}

}
