package com.nt.repository;

import org.springframework.data.repository.CrudRepository;

import com.nt.entity.StockInfo;

public interface IStockDetailsRepository extends CrudRepository<StockInfo, Integer> {

}
