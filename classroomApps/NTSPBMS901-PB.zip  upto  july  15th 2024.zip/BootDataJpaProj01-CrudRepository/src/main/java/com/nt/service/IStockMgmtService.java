package com.nt.service;

import java.util.List;
import java.util.Optional;

import com.nt.entity.StockInfo;

public interface IStockMgmtService {
  public  String registerStock(StockInfo  info);
  public  String   registerStocks(List<StockInfo> list);
  public   String   checkStockAvailability(int  stockId);
  public   long      showStocksCount();
  public  Iterable<StockInfo>   showAllStocks();
  public   Iterable<StockInfo>  showAllStocksByids(List<Integer> ids);
  public    Optional<StockInfo>   showStockDetailsById(int id);
  public    StockInfo   fetchStockDetailsById(int id);
  public    String      findStockDetailsById(int id);
  public    StockInfo    displayStockDetailsById(int id);
  public  String    modifyStockInfo(StockInfo  info);
  public   String     modifyStockPriceByStockId(int id, double hikePercentage,double  newAvailableUnits);
  
  public    String    removeStockById(int id);
  public    String    removeStock(StockInfo info);
  
  public     String    removeAllStocks();
  public    String  removeAllStockByIds(List<Integer> ids);
  
  
  
  
  
  
  
}
