package com.nt.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nt.entity.StockInfo;
import com.nt.repository.IStockDetailsRepository;

@Service("stockMgmtService")
public class StockMgmtServiceImpl implements IStockMgmtService {
	@Autowired
	private  IStockDetailsRepository  stockRepo;

	@Override
	public String registerStock(StockInfo info) {
		/*		//save object
			 StockInfo info1=	stockRepo.save(info);
				return  "Object is saved with the id Value:"+fo1.getStockId();*/
		System.out.println("Repo obj class name ::"+stockRepo.getClass()+"....."+Arrays.toString(stockRepo.getClass().getInterfaces()));
		    int idVal=stockRepo.save(info).getStockId();
		    return  "Object is saved with the id value ::"+idVal;
	}

	@Override
	public String registerStocks(List<StockInfo> list) {
		  stockRepo.saveAll(list);
		return  list.size()+"  no.of records are inserted";
	}
	
	@Override
	public String checkStockAvailability(int stockId) {
		//use repo
		return   stockRepo.existsById(stockId)? stockId+" Stock is avaiable":stockId+" Stock is not available";
		
		
	}
	
	@Override
	public long showStocksCount() {
		long count=stockRepo.count();
		return count;
	}
	
	@Override
	public Iterable<StockInfo> showAllStocks() {
		   return   stockRepo.findAll();
	
	}
	
	@Override
	public Iterable<StockInfo> showAllStocksByids(List<Integer> ids) {
				return stockRepo.findAllById(ids);
	}
	
		@Override
		public Optional<StockInfo> showStockDetailsById(int id) {
		      Optional<StockInfo> opt=stockRepo.findById(id);
		      return opt;
		}

	public StockInfo fetchStockDetailsById(int id) {
		/*   	Optional<StockInfo>  opt=stockRepo.findById(id);
		   	if(opt.isPresent()) {
		   		StockInfo info=opt.get();
		   		return info;
		   	}
		   	else {
		   		throw  new IllegalArgumentException("invalid stock id");
		   	}*/
		return  stockRepo.findById(id).orElseThrow(()-> new IllegalArgumentException("Invalid Stock Id"));
	}
	
	@Override
	public String findStockDetailsById(int id) {
	     Optional<StockInfo>  opt=stockRepo.findById(id);
	     if(opt.isPresent()) {
	    	 return  id+" stock id  stock details are ::"+opt.get();
	     }
		return  id+"  stock id is  found";
	}
	
	@Override
	public StockInfo displayStockDetailsById(int id) {
	     StockInfo info=stockRepo.findById(id).orElse(new StockInfo("xxx", "yyyy", "BSE","ZZZ",0.0, 0.0));
	    return info;
	}
	
	public  String    modifyStockInfo(StockInfo  info) {
		Optional<StockInfo> opt=stockRepo.findById(info.getStockId());
		if(opt.isPresent()) {
			//full object  modifiication
			stockRepo.save(info);
			return "Full objet is modified";
		}
		else {
			int idVal=stockRepo.save(info).getStockId();
			return idVal+"record inserted  nicesly";
		}
		
	}
	
	@Override
	public String modifyStockPriceByStockId(int id, double hikePercentage,double newAvailableUnits) {
		//Load object
		Optional<StockInfo> opt=stockRepo.findById(id);
		if(opt.isPresent()) {
			//get Entity obj
			StockInfo info=opt.get();
			//update the stock price
			info.setPrice(info.getPrice()+(info.getPrice()*hikePercentage/100.0));
			info.setAvaialbeUnits(newAvailableUnits);
			//udpate the obj
			stockRepo.save(info);
			return id+" Stock  value is updated";
		}
		else {
			return id +"Stock is not found  for updation";
		}
	
	}
	
	@Override
	public String removeStockById(int id) {
		//Load the object
		Optional<StockInfo> opt=stockRepo.findById(id);
		if(opt.isPresent()) {
			//delete the object by id
			stockRepo.deleteById(id);
			return  id+" record  is deleted";
		}
		return id+"  record is not found for deletion";
	}
	
	@Override
	public String removeStock(StockInfo info) {
		//Load the object
				Optional<StockInfo> opt=stockRepo.findById(info.getStockId());
				if(opt.isPresent()) {
					//delete the object
					stockRepo.delete(info);
					return  info.getStockId()+" record  is deleted";
				}
				return info.getStockId()+"  record is not found for deletion";

	}
	
	@Override
	public String removeAllStocks() {
		//get records count
		long count=stockRepo.count();
		if(count!=0) {
			stockRepo.deleteAll();
			return count+"no.of records are deleted";
		}
		return  "no records found for deletion";
	}
	
	@Override
	public String removeAllStockByIds(List<Integer> ids) {
		//load objects
		List<StockInfo> list=(List<StockInfo>)stockRepo.findAllById(ids);
		   //delete obj
		   stockRepo.deleteAllById(ids);
		   
		return list.size()+"no.of records are deleted";
	}
	

}
