package com.nt.runners;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.StockInfo;
import com.nt.service.IStockMgmtService;

@Component
public class CrudRepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private IStockMgmtService stockService;

	@Override
	public void run(String... args) throws Exception {
		/*	//use service
			try {
				StockInfo info=new StockInfo("Baja", "automobile","BSE", "Bajaj Company", 1456.0, 300000.0);
				String msg=stockService.registerStock(info);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/

			  try {
				  StockInfo  info1=new StockInfo("yamaha","automobile","BSE", "Yamaha India corp ", 1161.0,50000.0);
				  StockInfo  info2=new StockInfo("birla","Petrolium","NSE", "Bilra Group ", 3161.0,60000.0);
				  StockInfo  info3=new StockInfo("doch","IOT","BSE", "DOCH Smart devices", 4161.0,50000.0);
				  String  msg=stockService.registerStocks(List.of(info1, info2, info3));
				  System.out.println(msg);
			  }
			  catch(Exception  e) {
				  e.printStackTrace();
			  }

		/*   try {
			   String msg=stockService.checkStockAvailability(10016);
			   System.out.println(msg);
		   }
		   catch(Exception e) {
			   e.printStackTrace();
		   }*/

		/*	   try {
				   System.out.println("Count of stocks ::"+stockService.showStocksCount());
			   }
			   catch(Exception e) {
				   e.printStackTrace();
			   }*/

		/*    try {
		    	 Iterable<StockInfo>  it=stockService.showAllStocks();
					 it.forEach(stock->{
						 System.out.println(stock);
					 });
		    	 it.forEach(System.out::println);
		    }
		    catch(Exception e) {
		    	e.printStackTrace();
		    }*/
		
		/*	  try {
				   List<Integer>  ids=new ArrayList();
				   ids.add(1001); ids.add(1002);ids.add(3456);
				  Iterable<StockInfo> it=stockService.showAllStocksByids(ids);
				  System.out.println("retrived records count is ::"+((List<StockInfo>)it).size());
				  it.forEach(System.out::println);
			  }
			  catch(Exception e) {
				  e.printStackTrace();
			  }*/
		
		  /*try {*/
			   //Optional<StockInfo> opt=stockService.showStockDetailsById(101);
				/*	   if(opt.isPresent()) {
						   System.out.println("1001 stock details ::"+opt.get());
					   }
					   else {
						   System.out.println("Stock not found");
					   }
					   
				   }
				   catch(Exception  e) {
					   e.printStackTrace();
				   }*/
		
		/*	try {
				StockInfo  info=stockService.fetchStockDetailsById(1001);
				System.out.println(info);
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			   e.printStackTrace();	
			}*/
		
		/*   try {
			   String  msg=stockService.findStockDetailsById(11);
			   System.out.println(msg);
		   }
		   catch(Exception e) {
			 e.printStackTrace();  
		   }*/
		
			 /*try {
				   StockInfo info=stockService.displayStockDetailsById(1000);
				   System.out.println(info);
			   }
			   catch(Exception e) {
				 e.printStackTrace();  
			   }*/
		/*	 try {
				   StockInfo info=stockService.displayStockDetailsById(101);
				   System.out.println(info);
			   }
			*/
	
		/*	try {
				StockInfo info=new StockInfo(1006, "KFC2", "F&B2", "NSE2", "META2", 10.0, 3.0);
				String msg=stockService.modifyStockInfo(info);
				System.out.println(msg);
			
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		/*	try {
				String  msg=stockService.modifyStockPriceByStockId(1000, 10.0,5000.0);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
			 
		/*		 try {
					 String msg=stockService.removeStockById(1000);
					 System.out.println(msg);
				 }
				 catch(Exception e) {
					 e.printStackTrace();
				 }*/
		
		/*    try {
		    	String msg=stockService.removeStock(new StockInfo(1001, "xxx","aaa","yyyy","zzzz" , 0.0, 0.0));
		    	System.out.println(msg);
		    }
		    catch(Exception e) {
		    	e.printStackTrace();
		    }*/
		
		/*  try {
			  String msg=stockService.removeAllStocks();
			  System.out.println(msg);
		  }
		  catch(Exception e) {
			  e.printStackTrace();
		  }*/
		
		try {
			String msg=stockService.removeAllStockByIds(List.of(1001,1002,1008));
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		

	}// main

}// class
