package com.nt.service;

import org.springframework.data.domain.Page;

import com.nt.entity.StockInfo;

public interface IStockMgmtService {
   public Iterable<StockInfo>  showDataAsSorted(boolean ascOrder,String ...props);
   public   Page<StockInfo>   showStocksByPageNo(int  pageNo, int pagesize);
   public   Page<StockInfo>   showStocksByPageNoAsSorted(int  pageNo, int pagesize,boolean ascOrder,String ...props);
}
