package com.nt.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nt.entity.StockInfo;
import com.nt.repository.IStockInfoRepository;

@Service
public class StockMgmtServiceImpl implements IStockMgmtService {
	@Autowired
	private  IStockInfoRepository  stockRepo;

	@Override
	public Iterable<StockInfo> showDataAsSorted(boolean ascOrder, String... props) {
		// create  Sort obj  having Sorting  related info
		  Sort sort=Sort.by(ascOrder?Sort.Direction.ASC:Sort.Direction.DESC,props);
		//  get  the Sorted records
		  Iterable<StockInfo>  list=stockRepo.findAll(sort);
		return list;
	}
	
	@Override
	public Page<StockInfo> showStocksByPageNo(int pageNo, int pagesize) {
		 //create Pageable obj
		 Pageable pageable=PageRequest.of(pageNo, pagesize); 
		 //execute the method
		 Page<StockInfo>  page=stockRepo.findAll(pageable);
		return page;
	}
	
	@Override
	public Page<StockInfo> showStocksByPageNoAsSorted(int pageNo, int pagesize, boolean ascOrder, String... props) {
		//create Sort obj
		 Sort sort=Sort.by(ascOrder?Sort.Direction.ASC:Sort.Direction.DESC,props);
		 //create Pageable obj
		 Pageable pageable=PageRequest.of(pageNo, pagesize,sort); 
		 //execute the method
		 Page<StockInfo>  page=stockRepo.findAll(pageable);
		return page;
	}

}
