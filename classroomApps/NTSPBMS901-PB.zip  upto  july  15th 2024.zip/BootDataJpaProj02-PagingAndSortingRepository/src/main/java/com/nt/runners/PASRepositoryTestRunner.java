package com.nt.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.nt.entity.StockInfo;
import com.nt.service.IStockMgmtService;

@Component
public class PASRepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private IStockMgmtService  stockService;

	@Override
	public void run(String... args) throws Exception {
		
		//stockService.showDataAsSorted(false, "stockName").forEach(System.out::println);
		//stockService.showDataAsSorted(true, "exchangeName","company").forEach(System.out::println);
		
		/* Page<StockInfo> page=stockService.showStocksByPageNo(4, 3);
		 System.out.println(" page number::"+page.getNumber());
		 System.out.println("  page data::");
		    page.getContent().forEach(System.out::println);
		    System.out.println("Total of no.of pages::"+page.getTotalPages());
		    System.out.println("page size ::"+page.getSize());
		    System.out.println("no.records on the current page::"+page.getNumberOfElements());
		    System.out.println("is the current is first page ?"+page.isFirst());
		    System.out.println("is the current is last page ?"+page.isLast());*/
		
		
		 Page<StockInfo> page=stockService.showStocksByPageNoAsSorted(2, 3,true,"stockName");
		 System.out.println(" page number::"+page.getNumber());
		 System.out.println("  page data::");
		    page.getContent().forEach(System.out::println);
		    System.out.println("Total of no.of pages::"+page.getTotalPages());
		    System.out.println("page size ::"+page.getSize());
		    System.out.println("no.records on the current page::"+page.getNumberOfElements());
		    System.out.println("is the current is first page ?"+page.isFirst());
		    System.out.println("is the current is last page ?"+page.isLast());
		     
		     
		  

	}

}
