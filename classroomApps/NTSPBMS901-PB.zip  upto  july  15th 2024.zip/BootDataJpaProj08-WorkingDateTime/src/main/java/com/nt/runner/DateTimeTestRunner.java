package com.nt.runner;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Employee;
import com.nt.service.IEmployeeMgmtService;


@Component
public class DateTimeTestRunner implements CommandLineRunner {
	@Autowired
	private IEmployeeMgmtService  empService;

	@Override
	public void run(String... args) throws Exception {
		/*	//create entity object
			Employee emp=new Employee();
			emp.setEname("Rajesh"); emp.setEadd("hyd");
			emp.setDob(LocalDateTime.of(1960,10,30,11,50,34));
			emp.setToj(LocalTime.of(11, 30,40));
			emp.setDoj(LocalDate.of(1986, 11, 12));
			//save object
			String msg=empService.registerEmployee(emp);
			System.out.println(msg);*/
		
		  //empService.showAllEmloyees().forEach(System.out::println);
		
		   System.out.println("emp  age ::"+empService.findEmpAgeById(1));
		
	}
}
