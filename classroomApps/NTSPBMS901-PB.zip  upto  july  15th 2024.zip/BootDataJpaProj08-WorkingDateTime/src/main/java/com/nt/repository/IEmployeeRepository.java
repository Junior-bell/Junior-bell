package com.nt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.Employee;

public interface IEmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query(value="SELECT DATE_FORMAT(FROM_DAYS(DATEDIFF(NOW(),DOB)),'%Y') FROM JPA_JODA_EMPLOYEE WHERE EID=?1",nativeQuery = true)
	public  float   getEmpAgeById(int id);
}
