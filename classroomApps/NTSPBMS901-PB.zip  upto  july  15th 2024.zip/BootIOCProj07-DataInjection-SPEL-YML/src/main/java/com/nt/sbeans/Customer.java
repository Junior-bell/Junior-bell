package com.nt.sbeans;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("cust")
@ConfigurationProperties(prefix = "org.nt")
@Data
public class Customer {
	private String name;
	private  String addrs;
	private   Long pincode;
	private   String email;
	private   Integer size;
	

}
