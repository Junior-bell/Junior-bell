package com.nt.main;

import java.util.Arrays;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nt.config.AppConfig;
import com.nt.sbeans.WishMessageGenerator;

public class SpringBeanScopesTest {

	public static void main(String[] args) {
		System.out.println("DependencyInjectionTest.main()==>Start");
		//create  IOC container
		AnnotationConfigApplicationContext  ctx=new AnnotationConfigApplicationContext(AppConfig.class);
		
		System.out.println("-----------------------------------");
		
		WishMessageGenerator generator1=ctx.getBean("wishMessageGenerator",WishMessageGenerator.class);
		
		System.out.println("All Bean ids are ::"+Arrays.toString(ctx.getBeanDefinitionNames()));
		
		/*//get Target spring bean class obj
		WishMessageGenerator generator1=ctx.getBean("wmg",WishMessageGenerator.class);
		WishMessageGenerator generator2=ctx.getBean("wmg",WishMessageGenerator.class);
		System.out.println(generator1.hashCode()+"   "+generator2.hashCode());
		System.out.println("generator1==generator2?"+(generator1==generator2));
		*/
		
		/* Printer p1=ctx.getBean("prn",Printer.class);
		 Printer p2=ctx.getBean("prn",Printer.class);
		 System.out.println(p1.hashCode()+"  "+p2.hashCode());
		*/ 
		
		/*  System.out.println("---------------------------");
		  Date  d1=ctx.getBean("dt1",Date.class);
		  Date d2=ctx.getBean("dt2",Date.class);
		  System.out.println(d1.hashCode()+"  "+d2.hashCode());*/
		
		/* Printer p1=ctx.getBean("prn1",Printer.class);
		   Printer p2=ctx.getBean("prn2",Printer.class);
		   System.out.println(p1.hashCode()+"  "+p2.hashCode());
		*/    
		    
		
		
				  
		  //close the container
		    ctx.close();
       System.out.println("DependencyInjectionTest.main()===>end");
       
                 
	}

}
