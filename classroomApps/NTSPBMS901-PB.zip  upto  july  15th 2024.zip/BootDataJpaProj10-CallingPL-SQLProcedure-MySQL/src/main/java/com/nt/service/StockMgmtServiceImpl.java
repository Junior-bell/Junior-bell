package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.StockInfo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;

@Service
public class StockMgmtServiceImpl implements IStockMgmtService {
	@Autowired
	private  EntityManager  manager;
	
	/*	
		CREATE DEFINER=`root`@`localhost` PROCEDURE `p_get_Stock_byPriceRange`(in start float,
	        in  end  float)
	BEGIN
	select * from  stockInfo_tab  where  price>=start  and price<=end;
	END	*/

	@Override
	public List<StockInfo> showStocksByPriceRange(double start, double end) {
		
		//create StoredProcedureQuery obj
		StoredProcedureQuery  query=manager.createStoredProcedureQuery("p_get_Stock_byPriceRange",StockInfo.class);
		//register boht IN ,OUT params
		query.registerStoredProcedureParameter(1, Double.class, ParameterMode.IN);
		query.registerStoredProcedureParameter(2, Double.class, ParameterMode.IN);
		
		
		//set values to IN params
		query.setParameter(1, start);
		query.setParameter(2, end);
		
		//exeecute the PL/SQL procedure
		List<StockInfo> list=query.getResultList();
		return list;
	}

}
