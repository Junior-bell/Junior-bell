package com.nt.runner;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.MarriageSeeker;
import com.nt.service.IMarriageSeekerMgmtService;

@Component
public class LOBsTestRunner implements CommandLineRunner {
	@Autowired
	private  IMarriageSeekerMgmtService service;

	@Override
	public void run(String... args) throws Exception {
		 /*Scanner sc=new  Scanner(System.in);
		
		 
		 System.out.println("enter marrigeseeker Name::");
		 String name=sc.next();
		 System.out.println("enter marrigeseeker address::");
		 String addrs=sc.next();
		 System.out.println("enter marrigeseeker is  indian or nit::");
		 boolean isIndian=sc.nextBoolean();
		 
		 System.out.println("enter  photoPath::");
		 String  photoPath=sc.next();
		 
		 System.out.println("enter  resume Path::");
		 String  resumePath=sc.next();
		 
		 //create byte[]  by locating the file  if the file system
		 File file=new File(photoPath);
		 FileInputStream  fis=new FileInputStream(file);
		 byte[]  photoContent=new byte[fis.available()];
		 photoContent=fis.readAllBytes();		 
		//create char[]  by locating the file  if the file system
		  file=new File(resumePath);
		 FileReader reader=new FileReader(file);
		char[]  resumeContent=new char[(int)file.length()];
	     reader.read(resumeContent);
	     
	     
	     
	     
	     //create  Entity class obj
	     MarriageSeeker  seeker=new MarriageSeeker(name,addrs,isIndian,photoContent,resumeContent);
	     
	     
	    	 String resultMsg=service.registerMarriageSeeker(seeker);
	    	 System.out.println("Result Message is ::"+resultMsg);
	    	 
	    	 fis.close();
	    	reader.close();
	     
*/	
		// Logic  to retrieve  LOBS
		Scanner  sc=new Scanner(System.in);
		System.out.println("Enter  Marriage seeker Id");
		int  msId=sc.nextInt();
		
		//invoke  the service method
		Optional<MarriageSeeker> opt=service.getMarriageSeekerInfo(msId);
		if(opt.isPresent()) {
			//get Entity object
			MarriageSeeker  seeker=opt.get();
			System.out.println(seeker.getSid()+"..."+seeker.getName()+"...."+seeker.getAddrs()+"...."+seeker.getIndian());
			
			//read  the photo content (byte[]) from entity object  and write to  a file
			byte[] photoContent=seeker.getPhoto();
			try(FileOutputStream fos=new FileOutputStream("photo_retrieve.jpeg")){
				  fos.write(photoContent);
				  fos.flush();
				  System.out.println("Photo  is  retrived to a file");
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			   char[] resmeContent=seeker.getResume();
			//read  the resume content (char[]) from entity object  and write to  a file
				try(FileWriter writer=new FileWriter("resume_retrive.txt")){
				        writer.write(resmeContent);
				        writer.flush();
						  System.out.println("Resume  is  retrived to a file");
							
				}
				catch(Exception e) {
					e.printStackTrace();
				}
		}
		else {
			System.out.println(" Record not found");
		}
		
		
		
		
		
		
	  }//run(-) method
	}

