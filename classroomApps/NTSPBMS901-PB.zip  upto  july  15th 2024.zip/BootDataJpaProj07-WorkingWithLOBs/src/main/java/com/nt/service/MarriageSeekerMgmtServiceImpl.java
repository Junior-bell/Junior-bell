package com.nt.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.MarriageSeeker;
import com.nt.repository.IMarriageSkeerRepository;

@Service
public class MarriageSeekerMgmtServiceImpl implements IMarriageSeekerMgmtService {
	@Autowired
	private IMarriageSkeerRepository   marriageRpo;

	@Override
	public String registerMarriageSeeker(MarriageSeeker info) {
		int idVal=marriageRpo.save(info).getSid();
		return "MarriageSeeker is registered successfully with the id Value:"+idVal;
	}

	@Override
	public Optional<MarriageSeeker> getMarriageSeekerInfo(int id) {
		return  marriageRpo.findById(id);
	}

}
