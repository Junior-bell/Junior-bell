package com.nt.service;

import java.util.Optional;

import com.nt.entity.MarriageSeeker;

public interface IMarriageSeekerMgmtService {
   public  String  registerMarriageSeeker(MarriageSeeker info);
   public   Optional<MarriageSeeker>  getMarriageSeekerInfo(int id);
   
}
