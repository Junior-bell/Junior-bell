package com.nt.entity;

import java.io.Serializable;

import javax.swing.text.AbstractDocument.LeafElement;

import org.hibernate.Length;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name="JPA_LOB_MARRIAGE_SEEKER")
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class MarriageSeeker implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer  sid;
	@NonNull
	@Column(length = 20)
	private   String  name;
	@NonNull
	@Column(length = 25)
	private   String  addrs;
	@NonNull
	private   Boolean indian;
	@Lob
	@NonNull
	@Column(length =1255)
	private  byte[]   photo;
	@Lob
	@NonNull
	@Column(length =1255)
	private  char[]   resume;
	
	

}
