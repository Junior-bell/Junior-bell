package com.nt.runners;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
//@Order(-10)
public class TestRunner1 implements CommandLineRunner ,Ordered{

	@Override
	public void run(String... args) throws Exception {
     System.out.println("TestRunner1.run()(CLR)");
     System.out.println("cmd  line args::"+Arrays.toString(args));
     System.out.println("=========================");
     
  	
	}
	
	@Override
	public int getOrder() {
		// TODO Auto-generated method stub
		return -10;
	}

}
