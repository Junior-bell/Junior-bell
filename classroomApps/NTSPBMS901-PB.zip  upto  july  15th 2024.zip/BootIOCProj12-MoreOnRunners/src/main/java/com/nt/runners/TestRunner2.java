package com.nt.runners;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
//@Order(2)
public class TestRunner2 implements CommandLineRunner,Ordered {

	@Override
	public void run(String... args) throws Exception {
     System.out.println("TestRunner2.run()(CLR)");
     System.out.println("=====================");
  }
	
	@Override
	public int getOrder() {
		return 20;
	}

}
