package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootIocProj12MoreOnRunnersApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootIocProj12MoreOnRunnersApplication.class, args);
	}

}
