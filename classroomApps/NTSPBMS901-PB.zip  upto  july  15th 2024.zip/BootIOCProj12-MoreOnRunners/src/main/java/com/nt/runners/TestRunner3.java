package com.nt.runners;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(0)
public class TestRunner3 implements CommandLineRunner,Ordered {

	@Override
	public void run(String... args) throws Exception {
     System.out.println("TestRunner3.run()(CLR)");
     System.out.println("====================");
     
  	
	}
	
	@Override
	public int getOrder() {
		return 120;
	}
	
	

}
