package com.nt;

import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class BootSchedulingProj01Application {

	public static void main(String[] args) {
		System.out.println("BootSchedulingProj01Application.main() (start) ::"+new Date());
		SpringApplication.run(BootSchedulingProj01Application.class, args);
		
		System.out.println("BootSchedulingProj01Application.main() (end)::"+new Date());
	}

}
