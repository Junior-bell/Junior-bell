package com.nt.service;

import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class ReportGenerationService {

	/*	//@Scheduled(initialDelay =5000,fixedDelay= 3000)
		@Scheduled(fixedDelay= 3000)
		public   void  showReport() {
			System.out.println("Sales report on :"+new Date());
			try {
				Thread.sleep(1000);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println("------------------------");
		}
	*/

	/*//@Scheduled(initialDelay =5000,fixedDelay= 3000)
		@Scheduled(fixedDelay = 3000 )
		public   void  showReport() {
			System.out.println("Sales report on :"+new Date()+"thread name ::"+Thread.currentThread().getName());
					try {
						Thread.sleep(20000);
					}
					catch(Exception e) {
						e.printStackTrace();
					}
					System.out.println("------------------------"+new Date());
		}
	*/

	/*//@Scheduled(initialDelay =5000,fixedDelay= 3000)
		@Scheduled(fixedDelay= 3000)
		public   void  showReport(int start,int end) {
			System.out.println("ReportGenerationService.showReport() --> report on :"+new Date());
		}*/

	/*	
		//@Scheduled(cron="15 *  *  * * *")
		//@Scheduled(cron="* * *  * * *")
		//@Scheduled(cron="0 59 12  * * *")
		//@Scheduled(cron="0 3 13  29  6 *")
		//@Scheduled(cron="30  22,24  * * * *")
		@Scheduled(cron="30  31-33  * * * *")
		public void showReport() {
			System.out.println("Sales report on :" + new Date());
	  	}*/
	
	
	//@Scheduled(cron="${cron.expr}")
	//@Scheduled(cron="0 1/2 * * * *")
	//@Scheduled(cron="0/20 12/2 * * * *")
	//@Scheduled(cron="0 44 19 L * ?")  //last working day
	//@Scheduled(cron="0 46 19 ? * SUNL ")
	@Scheduled(cron="0  49 19 ? * SUN#5 ")
	public void showReport() {
		System.out.println("Sales report on :" + new Date());
  	}
	
	
}
