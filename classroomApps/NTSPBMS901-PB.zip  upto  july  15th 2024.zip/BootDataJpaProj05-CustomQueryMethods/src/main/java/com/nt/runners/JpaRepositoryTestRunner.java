package com.nt.runners;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.repository.IStockInfoRepository;

@Component
public class JpaRepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private  IStockInfoRepository  stockRepo;
	
	@Override
	public void run(String... args) throws Exception {
 
		
		
		//stockRepo.showAllStocks().forEach(System.out::println);
		 //stockRepo.showAllStocksByPriceRange(4000.0, 50000.0).forEach(System.out::println);
		/* stockRepo.showStocksByCompanyNames("TATA", "SBI Group").forEach(System.out::println);
		 System.out.println("----------------------");
		 stockRepo.showStocksDataByExchangeName("NSE").forEach(rowData->{
			 System.out.println(Arrays.toString(rowData));
		 });
		 System.out.println("----------------------");
		 stockRepo.showStockNamesByStockType("IT%").forEach(System.out::println);		 */
		
		/*	  System.out.println("stock data ::"+stockRepo.findStockByName("TATA-motors"));
			  System.out.println("----------------------");
				  
			  Object  rowData[]=(Object[])stockRepo.findStockDataByName("TATA-motors");
			  System.out.println("stock  data ::"+Arrays.toString(rowData));
			  System.out.println("----------------------");
				System.out.println("stock price::"+stockRepo.findStockPriceByName("TATA-motors"));*/
			
		/*  System.out.println("unique stock names are ::"+stockRepo.findStockNamesCount());
		  Object obj=stockRepo.findStockAggragateData();
		  Object  rowData[]=(Object[]) obj;
		  System.out.println("Aggregate results are ::"+Arrays.toString(rowData));*/
		
		
		/*	int count=stockRepo.updateStockPrice(10.0, "BSE");
			System.out.println("no.of stocks that are updated::"+count);*/
		
		     
		//System.out.println("no.of records that are deleted::"+stockRepo.removeStocksByPriceRange(1000.0, 2000.0));
		
		stockRepo.createTempTab();
		System.out.println("Sys date and time is ::"+stockRepo.showDate());
		  
		
		
		  
		  
	}// main

}// class
