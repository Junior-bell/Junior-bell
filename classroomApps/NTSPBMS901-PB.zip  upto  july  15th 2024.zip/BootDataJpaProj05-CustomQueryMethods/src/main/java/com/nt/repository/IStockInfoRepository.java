package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nt.entity.StockInfo;

import jakarta.transaction.Transactional;

public interface IStockInfoRepository extends  JpaRepository<StockInfo, Integer>              
 {
	   //@Query("from StockInfo")
		/*@Query("select st from StockInfo  as st")
		   public List<StockInfo>   showAllStocks();*/
	   
	 /*  @Query("from StockInfo where price>=?1 and price<=?2")
		//@Query("from StockInfo where  price>=:min and price<=:max ")
		   public   List<StockInfo>  showAllStocksByPriceRange(@Param("min") double startPrice,@Param("max") double endPrice); */
	
		//@Query("from StockInfo where  price>=:startPrice and price<=:endPrice ")
		/*   @Query("from StockInfo where  price>=?2 and price<=?3 ")
		 public   List<StockInfo>  showAllStocksByPriceRange(double startPrice, double endPrice);*/
	
	
		/*@Query("from StockInfo where  company in(:comp1,:comp2) order by company")  // entity select query -select all cols of the db table
		   public   List<StockInfo>   showStocksByCompanyNames(String  comp1,String comp2);
		
		@Query("select stockId,stockName,exchangeName from StockInfo where  exchangeName=:exName")   //scalar query-select multiple col values
		   public  List<Object[]>   showStocksDataByExchangeName(String exName);
		   
		   @Query("select stockName from StockInfo where  stockType like :initChars ")   //scalar query-select single col values
		   public  List<String>   showStockNamesByStockType(String initChars);*/
	
	
		/*@Query(" from StockInfo where  stockName=:name ") 
		       public   StockInfo    findStockByName(String  name);
		@Query("select stockId,stockName,price from StockInfo where  stockName=:name ") 
		   public Object   findStockDataByName(String name);
		@Query("select price from StockInfo where  stockName=:name ") 
		   public    Double    findStockPriceByName(String name);*/
	
		/*      @Query("select count(distinct stockName)  from StockInfo")
		      public   long     findStockNamesCount();
		  
		      @Query("select count(*),max(price),min(price),avg(price),sum(price)  from StockInfo")
		          public  Object  findStockAggragateData();
		  */
	
	        @Modifying
	        @Transactional
	       @Query("update   StockInfo set price=price+(price*:percentage/100.0) where exchangeName=:name")
	    public  int    updateStockPrice(double  percentage, String name);
	        
	        @Modifying
	        @Transactional
	       @Query("delete  from StockInfo where  price>=:start and price<=:end")
	        public  int    removeStocksByPriceRange(double start,double end);
	        
	        @Query(value="create table temp (col1 number(5)) ",nativeQuery = true)
	        @Modifying
	        @Transactional
	        public   int   createTempTab();
	        
	        @Query(value="select sysdate from dual ",nativeQuery = true)
	        public   String  showDate();
	
	        
	        
		   

		
}
