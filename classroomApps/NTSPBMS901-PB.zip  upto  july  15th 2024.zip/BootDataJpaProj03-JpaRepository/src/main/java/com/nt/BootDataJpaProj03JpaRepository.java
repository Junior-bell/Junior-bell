package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj03JpaRepository {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj03JpaRepository.class, args);
	}

}
