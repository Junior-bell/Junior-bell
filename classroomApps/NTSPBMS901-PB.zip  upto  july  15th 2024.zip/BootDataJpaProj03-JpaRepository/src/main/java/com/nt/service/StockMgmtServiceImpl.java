package com.nt.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nt.entity.StockInfo;
import com.nt.repository.IStockInfoRepository;

@Service
public class StockMgmtServiceImpl implements IStockMgmtService {
	@Autowired
	private  IStockInfoRepository  stockRepo;

	@Override
	public String removeStocksByIds(List<Integer> ids) {
		//Load  the records  by Ids
		List<StockInfo>  list=stockRepo.findAllById(ids);
		if(list.size()>0) {
			stockRepo.deleteAllByIdInBatch(ids);
			return  list.size()+"  no.of  records are deleted";
		}
		return "no  records are matched for deletion";
	}

	@Override
	public List<StockInfo> searchStocksByData(StockInfo info, boolean ascOrder, String... props) {
		//Sort obj
		 Sort sort=Sort.by(ascOrder?Sort.Direction.ASC:Sort.Direction.DESC,props);
		 //prepare obj
		 Example<StockInfo> example=Example.of(info);
		 //execute the method
		 List<StockInfo> list=stockRepo.findAll(example,sort);
		return list;
	}
	
	@Override
	public Optional<StockInfo> showStockById(Integer id) {
		  return  stockRepo.findById(id);
	}
	
	@Override
	public StockInfo fetchStockById(Integer id) {
		return stockRepo.getReferenceById(id);
	}

}
