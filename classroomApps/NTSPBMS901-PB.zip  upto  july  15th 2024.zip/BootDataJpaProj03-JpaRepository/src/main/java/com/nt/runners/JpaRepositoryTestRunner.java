package com.nt.runners;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.nt.entity.StockInfo;
import com.nt.service.IStockMgmtService;

@Component
public class JpaRepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private IStockMgmtService stockService;

	@Override
	public void run(String... args) throws Exception {

		/* try {
			 String msg=stockService.removeStocksByIds(List.of(1009,1010,1011,1021,1022));
			 System.out.println(msg);
		 }
		 catch(Exception e) {
			 e.printStackTrace();
		 }*/

		/*	try {
				//StockInfo info=new StockInfo(null,null,"Petrolium", "NSE", null, null, null);
				//StockInfo info=new StockInfo(null,"birla","Petrolium", "NSE", null, null, null);
				StockInfo info=new StockInfo();
				List<StockInfo> list=stockService.searchStocksByData(info, true, "stockId","stockName");
				list.forEach(stock->{
					System.out.println(stock);
				});
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/

		/*	  try {
			   //Optional<StockInfo>	opt=stockService.showStockById(1012);
				  stockService.showStockById(1012);
			   if(opt.isPresent()) {
				   System.out.println("record is  ::"+opt.get());
			   }
			   else {
				   System.out.println("reord not found");
			   }
			  }
			catch(Exception e) {
				e.printStackTrace();
			}*/

		  try {
		   StockInfo  info=stockService.fetchStockById(1050);
	      System.out.println("proxy obj class name::"+info.getClass()+"........"+info.getClass().getSuperclass());
	        System.out.println("stock id ::"+info.getStockId());
	         System.out.println("--------------------");
	         System.out.println("price::"+info.getPrice());
	         System.out.println("exchange name::"+info.getExchangeName());
		  }
		  catch(Exception e) {
			  e.printStackTrace();
			  System.out.println("Record not found");
		  }
		  
	}// main

}// class
