package com.nt.service;

import java.util.List;
import java.util.Optional;

import com.nt.entity.StockInfo;

public interface IStockMgmtService{
	 public   List<StockInfo>   searchStocksByData(StockInfo  info, boolean ascOrder , String ...props);
     public   String    removeStocksByIds(List<Integer> ids);
     public   Optional<StockInfo>   showStockById(Integer id);
     
     public  StockInfo    fetchStockById(Integer id);
     
}
